export const Data =
 [
    {
    "sections": [
        {
            "id": "toDo",
            "title": "ToDo",
            "card": [
                {
                    "taskType": "primary",
                    "taskid": 1,
                    "description": "Lorem Ipsum is simply dummy text of the printing",
                    "image": "",
                    "date": "",
                    "comments": '',
                    "attachment": "2",
                    "users": ['user1','user3']
                },
                {
                    "taskType": "secondary",
                    "taskid": 2,
                    "description": "Prepare moodboard for website branding",
                    "image": "",
                    "date": "",
                    "comments": '',
                    "attachment": "1",
                    "users": ['user2']
                },
                {
                    "taskType": "custom",
                    "taskid": 3,
                    "description": "Create announcement",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": '',
                    "attachment": "",
                    "users": ['user1','user2', 'user3']
                },
                {
                    "taskType": "primary",
                    "taskid": 4,
                    "description": "Lorem Ipsum is simply dummy text of the printing",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": '1',
                    "attachment": "",
                    "users": ['user1']
                },
                {
                    "taskType": "secondary",
                    "taskid": 5,
                    "description": "Lorem Ipsum is simply dummy text of the printing",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": '1',
                    "attachment": "2",
                    "users": ['user1']
                },

            ]
        },
        {
            "id": "inProgress",
            "title": "InProgress",
            "card": [
                {
                    "taskType": "primary",
                    "taskid": 6,
                    "description": "Prepare moodboard for website Lp",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": 4,
                    "attachment": "4",
                    "users": []
                },
                {
                    "taskType": "general",
                    "taskid": 7,
                    "description": "Fincal Editions",
                    "image": "image.png",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": 4,
                    "attachment": "5",
                    "users": []
                }
            ]
        },
        {
            "id": "inReview",
            "title": "InReview",
            "card": [
                {
                    "taskType": "custom",
                    "taskid": 8,
                    "description": "Interview with users",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": 4,
                    "attachment": "1",
                    "users": []
                },
                {
                    "taskType": "secondary",
                    "taskid": 9,
                    "description": "Create UI kit for project",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": 4,
                    "attachment": "3",
                    "users": []
                },
                {
                    "taskType": "primary",
                    "taskid": 10,
                    "description": "Lorem Ipsum is simply dummy text of the printing",
                    "image": "user4.png",
                    "date": "",
                    "comments": '',
                    "attachment": "2",
                    "users": ['user1','user3']
                },
                {
                    "taskType": "secondary",
                    "taskid": 11,
                    "description": "Prepare moodboard for website branding",
                    "image": "",
                    "date": "",
                    "comments": '',
                    "attachment": "1",
                    "users": ['user2']
                },
                {
                    "taskType": "custom",
                    "taskid": 12,
                    "description": "Create announcement",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": '',
                    "attachment": "",
                    "users": ['user1','user2', 'user3']
                },
            ]
        },
        {
            "id": "done",
            "title": "Done",
            "card": [
                {
                    "taskType": "secondary",
                    "taskid": 13,
                    "description": "Interview with users",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": 4,
                    "attachment": "1",
                    "users": [
                        
                    ]
                },
                {
                    "taskType": "secondary",
                    "taskid": 14,
                    "description": "Create UI kit for project",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": 2,
                    "attachment": "",
                    "users": []
                },
                {
                    "taskType": "primary",
                    "taskid": 15,
                    "description": "Lorem Ipsum is simply dummy text of the printing",
                    "image": "",
                    "date": "",
                    "comments": '',
                    "attachment": "2",
                    "users": ['user1','user3']
                },
                {
                    "taskType": "secondary",
                    "taskid": 16,
                    "description": "Prepare moodboard for website branding",
                    "image": "",
                    "date": "",
                    "comments": '',
                    "attachment": "1",
                    "users": ['user2']
                },
                {
                    "taskType": "custom",
                    "taskid": 17,
                    "description": "Create announcement",
                    "image": "",
                    "date": "2019-01-01T09:26:05.026Z",
                    "comments": '',
                    "attachment": "",
                    "users": ['user1','user2', 'user3']
                },
            ]
        }
    ]
}
]