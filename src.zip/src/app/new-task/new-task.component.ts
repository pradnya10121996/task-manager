import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-new-task',
  templateUrl: './new-task.component.html',
  styleUrls: ['./new-task.component.scss']
})
export class NewTaskComponent implements OnInit {
  formGroup: FormGroup;
 
  constructor(public dialog: MatDialog,private dialogRef: MatDialogRef<NewTaskComponent>,
    public formBuilder: FormBuilder) { }
    
  ngOnInit(): void {
    this.formGroup = this.formBuilder.group({
      title:['', Validators.required],
      description:['', Validators.required],
      name:['', Validators.required],
      image:['']
    })
  }

  onSubmit() {
    this.dialogRef.close(this.formGroup.value);
  }
  onNoClick(){
    this.dialogRef.close();
  }

}
