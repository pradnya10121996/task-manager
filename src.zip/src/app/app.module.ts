import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';




import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { LayoutModule } from '@angular/cdk/layout';

import { DragDropModule } from '@angular/cdk/drag-drop';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {MatButtonModule} from '@angular/material/button';


import {MatDialogModule} from '@angular/material/dialog';
import {MatInputModule} from '@angular/material/input';


import { CommonModule } from '@angular/common';

import { TasksComponent } from './tasks/tasks.component';
import {HttpClientModule } from '@angular/common/http';
import { CardsComponent } from './cards/cards.component';
import { NewTaskComponent } from './new-task/new-task.component';
import { SidenavComponent } from './sidenav/sidenav.component';
@NgModule({
  declarations: [
    AppComponent,
    TasksComponent,
    CardsComponent,
    NewTaskComponent,
    SidenavComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,

    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatInputModule,
     MatButtonModule,

    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
