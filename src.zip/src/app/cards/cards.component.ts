import { Component, Input, OnInit ,Output ,EventEmitter } from '@angular/core';
import { appConstants } from '../models/data/data.model';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.scss','../app.component.scss']
})
export class CardsComponent implements OnInit {
  @Input() cardData;
  public taskTypeListWithColor = appConstants.taskTypeListWithColor;
  @Output() delete = new EventEmitter<void>();
  @Input() taskType?: string;
  @Input() description: string;
  @Input() image?: string;
  @Input() date?: Date;
  @Input() comments?: string;
  @Input() attachment?: string;
  @Input() users?: [];
  @Input() taskId: number;
  constructor() { }

  ngOnInit(): void {

  }


}
