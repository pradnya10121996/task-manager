export interface Card {
  taskType?: taskType;
  taskid?:number;
  description: string;
  image?: string;
  date?: Date;
  comments?: string;
  attachment?: string;
  users?: [];
  name?: string;
  title?: string;
}
export interface Tasks {
  id: string;
  title: string;
  card: Card[];
}
export interface TaskList {
  sections: Tasks[];
}

export enum taskType {
  Primary = 'primary',
  Secondary = 'secondary',
  Custom = 'custom',
}

export const appConstants = {

  taskTypeListWithColor: {
      [taskType.Primary]: {
          name: taskType.Primary,
          color: '#fa681a'
      },
      [taskType.Secondary]: {
          name: taskType.Secondary,
          color: '#fada26'
      },
      [taskType.Custom]: {
          name: taskType.Custom,
          color: '#b4adaa'
      },
  }
};
