import { Injectable } from '@angular/core';
import { TaskList } from '../models/data/data.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  constructor(private httpClient: HttpClient) { }
  getDetails(): Observable<TaskList> {
    const url = 'assets/data.json';
    return this.httpClient.get<TaskList>(url);
  }
  getDetails1(){
    const url = 'assets/data.json';
    return this.httpClient.get(url);
  }
  updateTaskList(){}
}
