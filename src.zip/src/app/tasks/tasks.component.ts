import { Component, OnInit } from '@angular/core';
import { Tasks, Card } from '../models/data/data.model';
import { Data } from 'src/assets/data';
import { MatDialog } from '@angular/material/dialog';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { NewTaskComponent } from '../new-task/new-task.component';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss','../app.component.scss']
})
export class TasksComponent implements OnInit {
  taskList = [];
  totalSection;
  public taskStatusUpdated: boolean = false;
  public taskCreated: boolean = false;
  public updatedTaskSection: string;
  newTask;
  constructor(private _dialog: MatDialog) { }

  ngOnInit(): void {
    if (localStorage.getItem('taskData') !== null) {

      let taskUpdated = JSON.parse(localStorage.getItem('taskStatusUpdated'));
      if (taskUpdated && !null) {
        let getTaskList = JSON.parse(localStorage.getItem('taskData'));
        this.taskList = getTaskList;
        if (this.taskList[0]['sections']) {
          this.taskList = getTaskList;
        }
        else {
          this.taskList = [{ "sections": getTaskList }]
        }
      } else {
        this.taskList = JSON.parse(localStorage.getItem('taskData'));
      }
    } else {
      localStorage.setItem('taskData', JSON.stringify(Data));
      this.taskList = JSON.parse(localStorage.getItem('taskData'));
      
    }

  }

  onCdkListDrop(event: CdkDragDrop<Tasks[]>) {
    moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
  }

  onCardDrop(event: CdkDragDrop<Card[]>) {
    this.taskStatusUpdated = true
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);

      let updatedTask = event.container.id;
      let dataArray = event.container.data;
      let currentObjectId = dataArray[event.currentIndex].taskid;
      let currentIndexObj = dataArray[event.currentIndex];
      let taskMoved

      this.totalSection = this.taskList[0].sections;

      this.totalSection.forEach(function (taskList) {
        if (taskList.id == updatedTask) {
          taskMoved = taskList;
        }
        taskList.card = taskList.card.filter(function (card) {
          return card.taskid != currentObjectId;
        })
      });

      let updatedCard = {
        "taskType": currentIndexObj.taskType,
        "description": currentIndexObj.description,
        "image": currentIndexObj.image,
        "date": currentIndexObj.date,
        "comments": currentIndexObj.comments,
        "attachment": currentIndexObj.attachment,
        "users": currentIndexObj.users
      }
      taskMoved.card.push(updatedCard);
      localStorage.setItem('taskData', JSON.stringify(this.totalSection));
      localStorage.setItem("taskStatusUpdated", JSON.stringify(this.taskStatusUpdated));
    }
  }
  taskIds(taskListIndex): string[] {
    return this.taskList[taskListIndex].sections.map(task => task.id);
  }
  drop(e) {

  }
  createNewTask() {
    this._dialog.open(NewTaskComponent)
      .afterClosed()
      .subscribe(newTaskData => {
        if (newTaskData.title !== '') {
          this.newTask = {
            "description": newTaskData.description,
            "image": newTaskData?.image ? newTaskData?.image?.replace(/^.*\\/, "") : '',
            "name": newTaskData.name,
            "title": newTaskData.title,
          }
          this.taskList[0]?.sections[0].card.push(this.newTask);
          this.taskCreated = true;
          localStorage.setItem('taskData', JSON.stringify(this.taskList));
          localStorage.setItem("taskCreated", JSON.stringify(this.taskCreated));
        }
      })
  }
  deleteTask(task, section) {
    section.card.splice(section.card.indexOf(task), 1);
  }
}
